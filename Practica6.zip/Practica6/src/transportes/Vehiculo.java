/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportes;

/**
 *
 * @author 53dav
 */
public abstract class Vehiculo {
    
    private double velocidad;
    private String marca;
    private String modelo;
    
    public Vehiculo(){
        
    }
    
    public Vehiculo(String marca, String modelo){
        this(marca,modelo,0.0);
    }
    
    public Vehiculo(String marca, String modelo, double velocidad){
        this.marca = marca;
        this.modelo = modelo;
        setVelocidad(velocidad);
    }

    public double getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(double velocidad) {
        if (velocidad > 0)
            this.velocidad = velocidad;
    }
    
    public void acelerar(){
        setVelocidad(getVelocidad() + 10);
    }
    
    public void acelerar(double incremento){
        setVelocidad(getVelocidad() + Math.max(0, incremento));
    }
    
    public abstract String tipo();

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }
}
