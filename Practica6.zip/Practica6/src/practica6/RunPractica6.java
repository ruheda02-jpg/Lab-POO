/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica6;

import java.util.*;
import transportes.Vehiculo;

/**
 *
 * @author 53dav
 */
public class RunPractica6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Hibrido b = new Hibrido("BYD", "Dolphin", 30.00);
        System.out.println(b.tipo());
        b.acelerar();
        System.out.println("velocidad: " + b.getVelocidad());
        b.acelerar(20);
        System.out.println("velocidad: " + b.getVelocidad());
        b.cargar(50);
        b.cargarGas(30);
        
        AutoElectrico a = new AutoElectrico("JAC", "E10X", 20.00);
        System.out.println(a.tipo());
        a.acelerar();
        System.out.println("velocidad: " + a.getVelocidad());
        a.acelerar(20);
        System.out.println("velocidad: " + a.getVelocidad());
        a.cargar(50);
        
        AutoClasico c = new AutoClasico("Chevrolet", "Mustang", 40.00);
        System.out.println(c.tipo());
        c.acelerar();
        System.out.println("velocidad: " + c.getVelocidad());
        c.acelerar(20);
        System.out.println("velocidad: " + c.getVelocidad());
        c.cargarGas(30);
        
        
        List<Vehiculo> flota = Arrays.asList(b,a,c);
        
        System.out.println("MARCA"+"\tMODELO");
        for (Vehiculo v : flota){
            System.out.println(v.getMarca() + '\t' + v.getModelo());
        }
        
    }
    
}
