/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import tipoDeMotor.ICombustion;
import transportes.Vehiculo;

/**
 *
 * @author 53dav
 */
public class AutoClasico extends Vehiculo implements ICombustion{
    
    public AutoClasico(String marca, String modelo, double velocidad) {
        super(marca,modelo,velocidad);
    }

    @Override
    public String tipo() {
        return "Auto Clasico";
    }

    @Override
    public void cargarGas(double litros) {
        System.out.println("Cargando vehiculo modo gasolina");
    }
    
}
