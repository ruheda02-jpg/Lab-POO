package practica8;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;


public class LaboratorioColecciones {

    public static void main(String[] args) {
        
        System.out.println("== ArrayList: Exhibicion =="); 
        
        ArrayList<Producto> listaExhibicion = new ArrayList<>();
          
        listaExhibicion.add(new Producto(1, "Teclado", "Perifericos"));
        listaExhibicion.add(new Producto(2, "Mouse", "Perifericos"));
        listaExhibicion.add(new Producto(3, "Monitor", "Pantallas"));
        listaExhibicion.add(new Producto(4, "Cable HDMI", "Oferta"));
        
        for (Producto p : listaExhibicion)
            System.out.println(p);
        
        
        System.out.println("\n== LinkedList: Reabastecer ==");
        LinkedList<Producto> colaReabastecer = new LinkedList<>();
        
        colaReabastecer.addFirst(new Producto(6, "Webcam", "Perifericos"));
        colaReabastecer.addLast(new Producto(5, "Laptop", "Computo"));
        
        for (Producto p : colaReabastecer) 
            System.out.println(p);
        
        
        System.out.println("\n== HashSet: Categorias unicas ==");
        HashSet<String> categorias = new HashSet<>();
        
        categorias.add("Perifericos");
        categorias.add("Computo");
        categorias.add("Pantallas");
        categorias.add("Oferta");
        categorias.add("Perifericos"); 
        categorias.add("Computo");   
        
        System.out.println(categorias);
        
        
        System.out.println("\n== HashMap: Consulta por id ==");
        HashMap<Integer, Producto> mapaPorId = new HashMap<>();
        
        for (Producto p : listaExhibicion) 
            mapaPorId.put(p.getId(), p);
        for (Producto p : colaReabastecer) 
            mapaPorId.put(p.getId(), p);
        
        Producto buscado = mapaPorId.get(3);
        System.out.println("id=3 -> " + buscado);
        
        for (var entry : mapaPorId.entrySet()) 
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        
        
        System.out.println("\n== Iterator: eliminar categoria 'Oferta' en listaExhibicion ==");
        Iterator<Producto> it = listaExhibicion.iterator();
        while (it.hasNext()) {
            Producto p = it.next();
            if (p.getCategoria().equals("Oferta")) 
                it.remove();
        }
        
        System.out.println("Despues de eliminar:");
        for (Producto p : listaExhibicion) 
            System.out.println(p);
       
    }
    
}
