/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transportes;

/**
 *
 * @author 53dav
 */
public class Carro {

    /**
     * @return the gasolina
     */
    public double getGasolina() {
        return gasolina;
    }

    /**
     * @param gasolina the gasolina to set
     */
    public void setGasolina(double gasolina) {
        this.gasolina = gasolina;
    }
    
    String marca;
    int modelo;
    String color;
    private double gasolina;
    
    
    public Carro(){
    }
    
    public Carro(String marca, int modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public void displayInfo(){
        System.out.println("Marca: " + marca + ", Modelo: " + modelo);
        System.out.println("Color: " + color + ", Gasolina: " + getGasolina());
    }
    
    public void encenderMotor(){
        if (getGasolina() > 0)
            System.out.println("Motor automovil encendido");
        else
            System.out.println("Hace falta gasolina para arrancar");
    }
    
    public String avanzar(){
        String mensaje;
        
        if (getGasolina() > 5)
            mensaje = "Automovil Avanzando";
        else
            mensaje = "Hace falta gasolina para avanzar";
        
        return mensaje;
    }
}
