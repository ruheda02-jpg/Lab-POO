/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica2;

import Transportes.Automovil;
import Transportes.Carro;

/**
 *
 * @author 53dav
 */
public class RunPractica2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Automovil auto = new Automovil();
        auto.setMarca("Ford");
        System.out.println("El automovil marca: " + auto.getMarca());
        auto.encenderMotor();
        System.out.println(auto.avanzar());
       
        System.out.println("-----------Carro Taurus-------------");
        Carro taurus = new Carro();
        taurus.setGasolina(0);
        taurus.displayInfo();
        taurus.encenderMotor();
        System.out.println(taurus.avanzar());
        
        System.out.println("------------Carro Topaz------------");
        Carro topaz = new Carro("Ford", 2025, "Blanco");
        topaz.setGasolina(10);
        topaz.displayInfo();
        topaz.encenderMotor();
        System.out.println(topaz.avanzar());
        
        System.out.println("------------Carro Versa------------");
        Carro versa = new Carro("Nissan", 2020, "Negro");
        versa.setGasolina(30);
        versa.displayInfo();
        versa.encenderMotor();
        System.out.println(versa.avanzar());
        
        System.out.println("------------Carro Aveo------------");
        Carro aveo = new Carro("Chevrolet", 2015, "Gris");
        aveo.setGasolina(5);
        aveo.displayInfo();
        aveo.encenderMotor();
        System.out.println(aveo.avanzar());
    }
    
}
