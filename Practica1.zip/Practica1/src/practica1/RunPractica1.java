/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica1;

import Calculador.Calculadora;

/**
 *
 * @author 53dav
 */
public class RunPractica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Calculadora casio = new Calculadora();
        
        System.out.println("Sumar 10 + 54 = " + casio.suma(10, 54));
        System.out.println("Restar 10 - 5 = " + casio.resta(10, 5));
        System.out.println("Multiplicar 10 * 4 = " + casio.multiplicar(10, 4));
        System.out.println("Dividir 10 / 5 = " + casio.dividir(10, 5));
    }
    
}
