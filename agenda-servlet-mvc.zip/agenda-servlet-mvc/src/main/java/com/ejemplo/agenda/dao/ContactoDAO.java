/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.agenda.dao;

import com.ejemplo.agenda.model.Contacto;
import com.ejemplo.agenda.util.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 53dav
 */
public class ContactoDAO {
    
    public void insert(Contacto c) throws SQLException {
        String sql = "INSERT INTO contactos (nombre, apellidoPaterno, apellidoMaterno, sexo, telefono, direccion, tipoContacto) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, c.getNombre());
            stmt.setString(2, c.getApellidoPaterno());
            stmt.setString(3, c.getApellidoMaterno());
            stmt.setString(4, c.getSexo());
            stmt.setString(5, c.getTelefono());
            stmt.setString(6, c.getDireccion());
            stmt.setString(7, c.getTipoContacto());

            stmt.executeUpdate();
        }
    }
    
    public List<Contacto> getAll() throws SQLException {
        
        List<Contacto> lista = new ArrayList<>();

        String sql = "SELECT * FROM contactos";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Contacto c = new Contacto(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellidoPaterno"),
                    rs.getString("apellidoMaterno"),
                    rs.getString("sexo"),
                    rs.getString("telefono"),
                    rs.getString("direccion"),
                    rs.getString("tipoContacto")
                );
                lista.add(c);
            }
        }
        
        return lista;
    }

    public void update(Contacto c) throws SQLException{
        String sql = "UPDATE contactos SET nombre=?, apellidoPaterno=?, apellidoMaterno=?, sexo=?, telefono=?, direccion=?, tipoContacto=? WHERE id=?";
        
        try (Connection conn = DB.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

           stmt.setString(1, c.getNombre());
           stmt.setString(2, c.getApellidoPaterno());
           stmt.setString(3, c.getApellidoMaterno());
           stmt.setString(4, c.getSexo());
           stmt.setString(5, c.getTelefono());
           stmt.setString(6, c.getDireccion());
           stmt.setString(7, c.getTipoContacto());
           stmt.setInt(8, c.getId());

           stmt.executeUpdate();
       }
    }
    
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM contactos WHERE id=?";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    public Contacto getById(int id) throws SQLException {
        String sql = "SELECT * FROM contactos WHERE id=?";
        Contacto c = null;

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    c = new Contacto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellidoPaterno"),
                        rs.getString("apellidoMaterno"),
                        rs.getString("sexo"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getString("tipoContacto")
                    );
                }
            }
        }
        return c;
    }   
}
