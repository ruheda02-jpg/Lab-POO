/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.ejemplo.agenda.web;

import com.ejemplo.agenda.dao.ContactoDAO;
import com.ejemplo.agenda.model.Contacto;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;

/**
 *
 * @author 53dav
 */
@WebServlet(name = "ContactoServlet", urlPatterns = {"/ContactoServlet"})
public class ContactoServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ContactoServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ContactoServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "list"; // acción por defecto
        }

        switch (action) {
        case "list":
            listContactos(request, response);
            break;

        case "new":
            showForm(request, response, null); // formulario vacío para agregar
            break;

        case "edit":
            int id = Integer.parseInt(request.getParameter("id"));
            ContactoDAO dao = new ContactoDAO();
            try {
                Contacto c = dao.getById(id); // obtener contacto de la base de datos
                showForm(request, response, c);
            } catch (SQLException e) {
                throw new ServletException(e);
            }
            break;

        case "delete":
            int deleteId = Integer.parseInt(request.getParameter("id"));
            try {
                new ContactoDAO().delete(deleteId);
                response.sendRedirect("ContactoServlet?action=list");
            } catch (SQLException e) {
                throw new ServletException(e);
            }
            break;
    }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        // Obtener datos del formulario
        String idStr = request.getParameter("id");
        String nombre = request.getParameter("nombre");
        String apellidoPaterno = request.getParameter("apellidoPaterno");
        String apellidoMaterno = request.getParameter("apellidoMaterno");
        String sexo = request.getParameter("sexo");
        String telefono = request.getParameter("telefono");
        String direccion = request.getParameter("direccion");
        String tipoContacto = request.getParameter("tipoContacto");

        Contacto c = new Contacto();
        if (idStr != null && !idStr.isEmpty()) {
            c.setId(Integer.parseInt(idStr)); // editar
        }
        c.setNombre(nombre);
        c.setApellidoPaterno(apellidoPaterno);
        c.setApellidoMaterno(apellidoMaterno);
        c.setSexo(sexo);
        c.setTelefono(telefono);
        c.setDireccion(direccion);
        c.setTipoContacto(tipoContacto);

        ContactoDAO dao = new ContactoDAO();

        try {
            if (c.getId() == null) {
                dao.insert(c); // agregar
            } else {
                dao.update(c); // actualizar
            }
            response.sendRedirect("ContactoServlet?action=list");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listContactos(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        ContactoDAO dao = new ContactoDAO();
        try {
            request.setAttribute("contactos", dao.getAll());
            request.getRequestDispatcher("/views/lista.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Contacto c)
        throws ServletException, IOException {

        request.setAttribute("contacto", c); // puede ser null si es “nuevo”
        request.getRequestDispatcher("/views/form.jsp").forward(request, response);
    }    
}
