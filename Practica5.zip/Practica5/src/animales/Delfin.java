/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animales;

/**
 *
 * @author 53dav
 */
public class Delfin extends Animal implements IAcuatico {

    public Delfin(String nombre) {
        super(nombre);
    }
    
    String nombre = super.getNombre();

    @Override
    public void hacerSonido() {
        System.out.println( nombre + " hace chirridos.");
    }

    @Override
    public void nadar() {
        System.out.println( nombre + " nadando.");
    }
    
    @Override
    public String respirar(){
        return nombre + " esta respirando en la superficie";
    }
    
}
