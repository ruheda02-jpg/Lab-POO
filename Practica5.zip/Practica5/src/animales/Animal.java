/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animales;

/**
 *
 * @author 53dav
 */
public abstract class Animal {
    
    private String nombre;
    
    public Animal(String nombre){
        this.nombre = nombre;
    }
    
    public abstract void hacerSonido();
    
    public abstract String respirar();
    
    public void comer(){
        System.out.println(this.getNombre() + " comiendo.");
    }
    
    public void despertar(){
        System.out.println(this.getNombre() + " despertando.");
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }
    
}
