/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animales;

/**
 *
 * @author 53dav
 */
public class Perro extends Animal implements ITerrestre{

    public Perro(String nombre) {
        super(nombre);
    }
    
    String nombre = super.getNombre();

    @Override
    public void hacerSonido() {
        System.out.println( nombre + " esta ladrando.");
    }

    @Override
    public String respirar() {
        return nombre + " esta respirando.";
    }

    @Override
    public void correr() {
        System.out.println( nombre + " esta corriendo.");
    }

    @Override
    public void caminar() {
        System.out.println( nombre + " esta caminando.");
    }
    
}
