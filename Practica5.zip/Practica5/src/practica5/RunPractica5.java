/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica5;

import animales.Aguila;
import animales.Delfin;
import animales.Perro;

/**
 *
 * @author 53dav
 */
public class RunPractica5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Delfin d = new Delfin("flipper");
        
        String r = d.respirar();
        System.out.println(r);
        d.despertar();
        d.hacerSonido();
        d.comer();
        d.nadar();
        
        System.out.println("\n");
        Aguila a = new Aguila("gulfan");
        a.comer();
        a.despertar();
        a.hacerSonido();
        a.volar();
        System.out.println(a.respirar());
        
        System.out.println("\n");
        Perro p = new Perro("oggy");
        p.caminar();
        p.comer();
        p.correr();
        p.despertar();
        p.hacerSonido();
        System.out.println(p.respirar());
        
    }
    
}
