/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.ejemplo.agenda.web;

import com.ejemplo.agenda.dao.ContactoDAO;
import com.ejemplo.agenda.model.Contacto;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 53dav
 */
@WebServlet(name = "ContactoServlet", urlPatterns = {"/contactos"})
public class ContactoServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "listar";
        }

        ContactoDAO dao = new ContactoDAO();
        int id;

        switch (action) {
            case "nuevo":
                request.getRequestDispatcher("views/form.jsp").forward(request, response);
                break;

            case "editar":
                id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("contacto", dao.obtenerPorId(id));
                request.getRequestDispatcher("views/form.jsp").forward(request, response);
                break;

            case "eliminar":
                id = Integer.parseInt(request.getParameter("id"));
                dao.eliminar(id);
                response.sendRedirect("contactos");
                break;

            default:
                request.setAttribute("lista", dao.listar());
                request.getRequestDispatcher("views/lista.jsp").forward(request, response);
                break;
        }
    }


    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Contacto c = new Contacto();
        c.setNombre(request.getParameter("nombre"));
        c.setApellidoPaterno(request.getParameter("apellidoPaterno"));
        c.setApellidoMaterno(request.getParameter("apellidoMaterno"));
        c.setSexo(request.getParameter("sexo"));
        c.setTelefono(request.getParameter("telefono"));
        c.setDireccion(request.getParameter("direccion"));
        c.setTipoContacto(request.getParameter("tipoContacto"));

        ContactoDAO dao = new ContactoDAO();

        String idStr = request.getParameter("id");

        if (idStr == null || idStr.trim().isEmpty()) {
            dao.insertar(c);
        } else {
            c.setId(Integer.parseInt(idStr));
            dao.actualizar(c);
        }
        
        response.sendRedirect("contactos");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
