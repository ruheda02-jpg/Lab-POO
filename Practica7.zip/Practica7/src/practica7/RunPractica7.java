/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

import java.util.ArrayList;
import transportes.IOperable;
import transportes.Transporte;
import transportes.TransporteAereo;
import transportes.TransporteFerroviario;
import transportes.TransporteMaritimo;
import transportes.TransporteTerrestre;


public class RunPractica7 {

    public static void main(String[] args) {
        
        ArrayList<Transporte> transportes = new ArrayList<>();
        transportes.add(new TransporteMaritimo("BAR-01", 100));
        transportes.add(new TransporteTerrestre("BUS-22", 50));
        transportes.add(new TransporteAereo("AV-777", 200));
        transportes.add(new TransporteFerroviario("FER-09", 300)); // nuevo

        for (Transporte t : transportes) {
            t.mover();
            try {
                t.transportar(60);
            } catch (CapacidadExcedidaException e) {
                System.out.println(e.getMessage());
            }
            ((IOperable) t).realizarMantenimiento();
            System.out.println("---");
        }
        
        try {
            Transporte trenSobrecargado = new TransporteFerroviario("FER-99", 800);
        } catch (IllegalArgumentException e) {
            System.out.println("ERROR en creacion: " + e.getMessage());
        }
        
    }
    
}
