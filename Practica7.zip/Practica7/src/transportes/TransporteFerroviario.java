/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportes;

/**
 *
 * @author 53dav
 */
public class TransporteFerroviario extends Transporte implements IOperable {
    
    public TransporteFerroviario(String id, int capacidad) {
        super(id, capacidad);
    }

    @Override
    public String tipo() {
        return "Transporte Ferroviario";
    }

    @Override
    public void mover() {
        System.out.println("Avanzando sobre rieles...");
    }

    @Override
    public void realizarMantenimiento() {
        System.out.println("Mantenimiento ferroviario: revision de rieles y vagones.");
    }
    
}
