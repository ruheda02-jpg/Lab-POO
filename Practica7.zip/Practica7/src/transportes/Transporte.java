/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportes;

import practica7.CapacidadExcedidaException;

public abstract class Transporte {
    
    private String id;
    private int capacidad;

    public Transporte(String id, int capacidad) {
        setId(id);
        setCapacidad(capacidad);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        if (capacidad > 500) {
            throw new IllegalArgumentException(
                "Capacidad invalida: " + capacidad + " (maximo permitido: 500)"
            );
        }
        this.capacidad = capacidad;
    }

    public void transportar(int pasajeros) throws CapacidadExcedidaException {
        if (pasajeros > capacidad) {
            throw new CapacidadExcedidaException(
                "ERROR: Pasajeros (" + pasajeros + ") exceden capacidad (" + capacidad + ") en " + tipo()
            );
        }
        System.out.println("Transportando " + pasajeros + " pasajeros en " + tipo() + " [" + id + "]");
    }

    public abstract String tipo();
    
    public abstract void mover();
    
}
