/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica3;

/**
 *
 * @author 53dav
 */
public class RunPractica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        CuentaBancaria cuentaBanamex = new CuentaBancaria();
        cuentaBanamex.setNumeroCuenta("98765432");
        cuentaBanamex.setTitular("Pedro Navajas");
        cuentaBanamex.setSaldo(5000);
        
        System.out.println("Saldo inicial: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.depositar(500);
        System.out.println("Despues del deposito: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.retirar(400);
        System.out.println("Despues del retiro: " + cuentaBanamex.getSaldo());
        
        cuentaBanamex.retirar(6400);
        
        CuentaBancaria cuentaBBVA = new CuentaBancaria("12345678", "Gustavo Ruiz", 2000);
        
        cuentaBBVA.depositar(1000);
        System.out.println("Despues del deposito: " + cuentaBBVA.getSaldo());
        cuentaBBVA.retirar(1500);
        System.out.println("Despues del retiro: " + cuentaBBVA.getSaldo());
        cuentaBBVA.retirar(3500);
        
    }
    
}
