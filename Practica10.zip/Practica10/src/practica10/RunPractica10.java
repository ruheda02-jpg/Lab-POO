package practica10;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class RunPractica10 {

    public static void main(String[] args) {
        
        File carpeta = new File("sucursales");
        if (!carpeta.exists()) 
        {
            carpeta.mkdir();
            System.out.println("Carpeta 'sucursales' creada.");
        } 
        else 
            System.out.println("Carpeta 'sucursales' ya existe.");
        
        File archivo1 = new File(carpeta, "sucursal1.txt");
        
        try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(archivo1))) 
        {
            bw1.write("""
                      Ana
                      Luis
                      Sofia""");
        }
        catch (IOException e) 
        {
            System.out.println("Error al escribir en el archivo sucursal 1: " + e.getMessage());
        }
        
        File archivo2 = new File(carpeta, "sucursal2.txt");
        
        try (BufferedWriter bw2 = new BufferedWriter(new FileWriter(archivo2))) 
        {
            bw2.write("""
                      Carlos
                      Marta
                      Pedro""");
        }
        catch (IOException e) 
        {
            System.out.println("Error al escribir en el archivo sucursal 2: " + e.getMessage());
        }
        
        File archivo3 = new File(carpeta, "sucursal3.txt");
        
        try (BufferedWriter bw3 = new BufferedWriter(new FileWriter(archivo3))) 
        {
            bw3.write("""
                      Laura
                      Jorge
                      Diego""");
        }
        catch (IOException e) 
        {
            System.out.println("Error al escribir en el archivo sucursal 3: " + e.getMessage());
        }
        
        LectorArchivo hilo1 = new LectorArchivo("sucursales/sucursal1.txt");
        LectorArchivo hilo2 = new LectorArchivo("sucursales/sucursal2.txt");
        LectorArchivo hilo3 = new LectorArchivo("sucursales/sucursal3.txt");


        hilo1.setName("Hilo-1");
        hilo2.setName("Hilo-2");
        hilo3.setName("Hilo-3");

        hilo1.start();
        hilo2.start();
        hilo3.start();
   
    }
    
}
