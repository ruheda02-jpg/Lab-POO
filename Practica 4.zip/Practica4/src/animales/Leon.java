/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animales;

/**
 *
 * @author 53dav
 */
public class Leon extends Gato{
    
    public Leon(String nombre) {
        super(nombre);
    }
    
    public void hacerSonidos(){
        System.out.println("El leon ruge.");
    }
    
    public void correr(){
        System.out.println("El leon corre.");
    }
    
    public String comer(){
        
        return "El leon esta Comiendo.";
    }
    
    public String cazar(){
        
        return "El leon esta cazando.";
    }
    
}
