/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animales;

/**
 *
 * @author 53dav
 */
public class Pato extends Pajaro {
    
    public Pato(String nombre) {
        super(nombre);
    }
    
    public void nadar(){
        System.out.println("El pato esta nadando");
    }
    
    
}
