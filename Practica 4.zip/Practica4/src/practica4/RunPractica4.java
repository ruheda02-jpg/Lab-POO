/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4;
import animales.*;
/**
 *
 * @author 53dav
 */
public class RunPractica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Animal a = new Animal("Electrico");
        Gato g = new Gato("Pinut");
        Pajaro p = new Pajaro("Loco");
        Pato patito = new Pato("Dulce");
        Leon l = new Leon("Gatito");
        
        System.out.println("Animal");
        a.mostrarNombre();
        a.hacerSonidos();
        System.out.println(a.comer());
        
        System.out.println("Gato");
        g.mostrarNombre();
        g.hacerSonidos();
        System.out.println(g.comer());
        
        System.out.println("Pajaro");
        p.mostrarNombre();
        p.volar();
        p.hacerSonidos();
        System.out.println(p.comer());
        
        System.out.println("Pato");
        patito.mostrarNombre();
        patito.volar();
        patito.hacerSonidos();
        System.out.println(patito.comer());
        patito.nadar();
        
        System.out.println("Leon");
        l.mostrarNombre();
        l.hacerSonidos();
        l.correr();
        System.out.println(l.comer());
        System.out.println(l.cazar());
    }
    
}
