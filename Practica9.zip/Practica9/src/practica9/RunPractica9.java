package practica9;

import java.io.*;
import java.util.Scanner;

public class RunPractica9 {

    public static void main(String[] args) 
    {

        File carpeta = new File("datos");
        if (!carpeta.exists()) 
        {
            carpeta.mkdir();
            System.out.println("Carpeta 'datos' creada.");
        } 
        else 
            System.out.println("Carpeta 'datos' ya existe.");
        
        File archivo = new File(carpeta, "productos.txt");

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) 
        {
            Scanner sc = new Scanner(System.in);

            System.out.println("\n=== Registro de productos ===");
            System.out.print("Cuantos productos quieres agregar?: ");
            int n = sc.nextInt();
            sc.nextLine(); 

            for (int i = 1; i <= n; i++) 
            {
                System.out.println("\nProducto #" + i);
                System.out.print("ID: ");
                int id = sc.nextInt();
                sc.nextLine(); 

                System.out.print("Nombre: ");
                String nombre = sc.nextLine();

                System.out.print("Categoria: ");
                String categoria = sc.nextLine();

                bw.write(id + "," + nombre + "," + categoria);
                bw.newLine();
            }

            System.out.println("\nProductos guardados correctamente.");

        } 
        catch (IOException e) 
        {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }

        System.out.println("\n=== Lectura del archivo ===");
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) 
        {
            String linea;
            while ((linea = br.readLine()) != null) 
                System.out.println(linea);
            
        } 
        catch (IOException e) 
        {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }

        System.out.println("\n=== Archivos en la carpeta 'datos' ===");
        File[] archivos = carpeta.listFiles();
        if (archivos != null) 
        {
            for (File f : archivos) 
                System.out.println(f.getName());
            
        } 
        else 
            System.out.println("No se pudo acceder a la carpeta.");
    }  
}
